#!/bin/bash
#
#lime & volatilty build script

OSVER=el7
ARCH=x86_64
KVER1=$1.${OSVER}.noarch
KVER=$1.${OSVER}.${ARCH}
export ARCH
export KVER

# import KVER into bash environment
# this is used to override the default value in LiME build
if [[ ! -z "${KVER}" ]]; then
echo "export ARCH=${ARCH}" >> /tmp/.bashrc
echo "export KVER=${KVER}" >> /tmp/.bashrc
source /tmp/.bashrc;
else
  exit 0
fi

# look for local copies of rpms and install from vault if missing
if [ ! -f "/rpms/kernel-${KVER}.rpm" ]; then
  echo "No local rpms found, pulling from vault..."
  yum -y -q -e 0 install kernel-${KVER} kernel-devel-${KVER} kernel-firmware*
  yum -y -q -e 0 install --enablerepo=debuginfo kernel-devel-${KVER} kernel-debuginfo-${KVER} kernel-debuginfo-common-${ARCH}-${KVER}
else
  echo "Local rpms found, installing..."
  yum install -y -q -e 0 /rpms/kernel-${KVER}.rpm /rpms/kernel-devel-${KVER}.rpm /rpms/kernel-firmware-${KVER1}.rpm
  yum -y -q -e 0 install --enablerepo=debuginfo kernel-devel-${KVER}.rpm kernel-debuginfo-${KVER}.rpm kernel-debuginfo-common-${ARCH}-${KVER}.rpm
fi

yum -y -q -e 0 install golang

# build basic volatility paths
mkdir -p /lime-module/${KVER}/boot
mkdir -p /lime-module/${KVER}/volatility/tools/linux/
mkdir -p /lime-module/${KVER}/volatility3/

# build lime kernel module
cd /LiME/src
echo "Building lime module..."
make > /tmp/log-file 2>&1
cp lime-${KVER}.ko /lime-module/${KVER}
cp /boot/System.map-${KVER} /lime-module/${KVER}/boot
cd /

# build dwarfdump module
cd /volatility/tools/linux
echo "Building dwarf module..."
make > /tmp/log-file 2>&1
cp module.dwarf /lime-module/${KVER}/volatility/tools/linux/
cd /

#Making ZIP of System.map and module.dwarf for Volatility2 Profile
cd /lime-module/${KVER}/
zip -9 -q -r ${KVER}_el7_vol2profile.zip volatility/tools/linux/module.dwarf boot/System.map-${KVER}
rm -rf volatility/ boot/
cd /

# Getting vmlinux (Volatility3 Profile)
echo "Building volatility3 Profile..."
cp /usr/lib/debug/lib/modules/`uname -r`/vmlinux /lime-module/${KVER}/volatility3/
cd /dwarf2json
go build
./dwarf2json linux --elf /lime-module/${KVER}/volatility3/vmlinux > /lime-module/${KVER}/volatility3/${KVER}_el7_vol3profile.json
cd /lime-module/${KVER}/volatility3/
zip -9 -q -r ${KVER}_el7_vol3profile.zip vmlinux ${KVER}_el7_vol3profile.json
cp ${KVER}_el7_vol3profile.zip /lime-module/${KVER}/
rm -rf /lime-module/${KVER}/volatility3

# zip up results into a volatility formatted file
cd /
echo "Building ${KVER} volatility zip file..."
for f in /lime-module/${KVER}/*; do
  [ -e "$f" ] && rm -f /rpms/${KVER}_mdump.zip && zip -9 -q -r /rpms/${KVER}_mdump.zip /lime-module/${KVER}/
done
echo "The Kernel Object, Volatility2 and Volatility3 Profiles are saved as ${KVER}_mdump.zip at `pwd`."
#docker cp mdump:/rpms/${KVER}_mdump.zip /root/linux_memprofiles/
#echo "${KVER}_mdump.zip is located at /root/linux_memprofiles/."
