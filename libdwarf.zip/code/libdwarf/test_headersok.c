/*   Just to verify no typos preventing inclusion */
/*   This test code is hereby placed in the public domain. */
#include "dwarf_reloc_386.h"
#include "dwarf_reloc_mips.h"
#include "dwarf_reloc_ppc.h"
#include "dwarf_reloc_arm.h"
#include "dwarf_reloc_ppc64.h"
#include "dwarf_reloc_x86_64.h"

int main()
{
    return 0;
}
